﻿namespace TaskFinal;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

public static class Global
{


    public static List<TaskModel> tasks = new List<TaskModel>();


    public static List<TaskModel> GetAllTasks()
    {
        LoadTasks();
        return tasks;
    }

    private static void LoadTasks()
    {
        var filePath = "Tasks.json";
        if (File.Exists(filePath))
        {
            var json = File.ReadAllText(filePath);
            tasks = JsonSerializer.Deserialize<List<TaskModel>>(json);
         
        }
    }

    public static void AddTask(TaskModel newTask)
    {

        int newID = tasks.Count()+1;
        for (int i = 0; i < tasks.Count(); i++)
        {
            if (newID== tasks[i].Id)
            {
                newID++;
            }
        }
        tasks.Add(newTask);
        newTask.Id = newID;
        
        if(newTask.CompletionDate <= DateTime.Now)
        {
            newTask.IsCompleted = true;
        }
        SaveTasksToFile();
    }

    public static void RemoveTask(int taskId)
    {
   
        for (int i = 0; i < tasks.Count(); i++)
        {
            if (tasks[i].Id == taskId)
            {
                tasks.RemoveAt(i);
                SaveTasksToFile();
            }
        }

   
    }
    public static TaskModel GetTaskById(int id)
    {
        foreach (var task in tasks)
        {
            if (task.Id == id)
            {
                return task; 
            }
        }

        return null;
    }


 

    public static void SaveTasksToFile()
    {
        var options = new JsonSerializerOptions
        {
            WriteIndented = true,
        };

        var json = JsonSerializer.Serialize(tasks, options);
        var filePath = "Tasks.json"; 

        File.WriteAllText(filePath, json);
    }
}
