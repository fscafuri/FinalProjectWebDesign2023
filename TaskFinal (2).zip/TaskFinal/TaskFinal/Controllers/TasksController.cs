﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
namespace TaskFinal.Controllers;



[ApiController]
[Route("api/tasks")]
public class TasksController : ControllerBase
{
    private static List<TaskModel> tasks;

    public TasksController()
    {
        InitializeTasksFromJson();
    }

    [HttpGet]
    public ActionResult<IEnumerable<TaskModel>> GetAllTasks()
    {
        return Ok(tasks);
    }

    [Route("completed")]
    public ActionResult<IEnumerable<TaskModel>> GetAllCompletedTasks()
    {
        List<TaskModel> completedTasks = new List<TaskModel>();

        foreach (var task in tasks)
        {
            if (task.IsCompleted)
            {
                completedTasks.Add(task);
            }
        }

        return Ok(completedTasks);
    }

    [Route("{id}")]
    public ActionResult<TaskModel> GetTaskById(int id)
    {
        foreach (var task in tasks)
        {
            if (task.Id == id)
            {
                return Ok(task);
            }
        }

        return null; 
        
    }

    [Route("[action]/{id:int}/{newDescription}")]
    public string EditTask(int id, string newDescription)
    {


        for (int i = 0; i < tasks.Count(); i++)
        {
            if (tasks[i].Id == id)
            {
                tasks[i].Description = newDescription; 
                SaveTasksToFile();
                return "Success";
            }
        }

        return "Failure";
    }



    [Route("[action]/{id:int}")]
    public string MarkTaskAsCompleted(int id)
    {

        for(int i = 0; i < tasks.Count(); i++)
        {
            if (tasks[i].Id == id)
            {
                tasks[i].IsCompleted = true;
                tasks[i].CompletionDate = DateTime.Now;
                SaveTasksToFile();
                return "Success";
            }
        }
        
        return "Failure";
    }

    private void InitializeTasksFromJson()
    {
        var filePath = "Tasks.json";
        if (System.IO.File.Exists(filePath))
        {
            var json = System.IO.File.ReadAllText(filePath);
            tasks = JsonSerializer.Deserialize<List<TaskModel>>(json);

        }
    }

    public static void SaveTasksToFile()
    {
        var options = new JsonSerializerOptions
        {
            WriteIndented = true,
        };

        var json = JsonSerializer.Serialize(tasks, options);
        var filePath = "Tasks.json";

        System.IO.File.WriteAllText(filePath, json);
    }
}