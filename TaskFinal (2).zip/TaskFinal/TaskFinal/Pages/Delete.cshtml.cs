
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using TaskFinal;

namespace TaskFinal.Pages
{
    public class DeleteModel : PageModel
    {
        public List<TaskModel> AllTasks { get; private set; }

        public void OnGet()
        {
          
            AllTasks = Global.GetAllTasks();
        }

        public IActionResult OnPostDelete(int id)
        {
           
            Global.RemoveTask(id);

      
            return RedirectToPage("Index");
        }
    }
}
