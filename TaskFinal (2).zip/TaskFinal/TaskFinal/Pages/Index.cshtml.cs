﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using TaskFinal;

namespace TaskFinal.Pages {
    public class IndexModel : PageModel
    {
        public List<TaskModel> AllTasks { get; private set; }

        public void OnGet()
        {
           
            AllTasks = Global.GetAllTasks();
        }
    }
}