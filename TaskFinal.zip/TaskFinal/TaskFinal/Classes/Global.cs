﻿namespace TaskFinal;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

public static class Global
{


    public static List<TaskModel> tasks = new List<TaskModel>();


    public static List<TaskModel> GetAllTasks()
    {
        LoadTasks();
        return tasks;
    }

    private static void LoadTasks()
    {
        var filePath = "Tasks.json";
        if (File.Exists(filePath))
        {
            var json = File.ReadAllText(filePath);
            tasks = JsonSerializer.Deserialize<List<TaskModel>>(json);
         
        }
    }

    public static void AddTask(TaskModel newTask)
    {
        tasks.Add(newTask);
        newTask.Id = tasks.Count();
        SaveTasksToFile();
    }

    public static void RemoveTask(int taskId)
    {
        TaskModel taskToRemove = tasks.FirstOrDefault(t => t.Id == taskId);

        if (taskToRemove != null)
        {
            tasks.Remove(taskToRemove);
            SaveTasksToFile();
        }
    }
    public static TaskModel GetTaskById(int id)
    {
        foreach (var task in tasks)
        {
            if (task.Id == id)
            {
                return task; 
            }
        }

        return null;
    }


 

    public static void SaveTasksToFile()
    {
        var options = new JsonSerializerOptions
        {
            WriteIndented = true,
        };

        var json = JsonSerializer.Serialize(tasks, options);
        var filePath = "Tasks.json"; 

        File.WriteAllText(filePath, json);
    }
}
