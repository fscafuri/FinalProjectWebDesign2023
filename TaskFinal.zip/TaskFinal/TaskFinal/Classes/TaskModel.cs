﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace TaskFinal;

public class TaskModel
{
    [Display(Name = "Id:")]
    public int Id { get; set; }

    [Display(Name = "Description:")]
    public string Description { get; set; }

    [Display(Name = "Due Date:")]
    public DateTime DueDate { get; set; }

    [Display(Name = "Completed Status:")]
    public bool IsCompleted { get; set; }

    [Display(Name = "Completion Date:")]
    public DateTime CompletionDate { get; set; }


}
