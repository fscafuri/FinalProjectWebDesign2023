﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
namespace TaskFinal.Controllers;



[ApiController]
[Route("api/tasks")]
public class TasksController : ControllerBase
{
    private static List<TaskModel> tasks;

    public TasksController()
    {
        InitializeTasksFromJson();
    }

    [HttpGet]
    public ActionResult<IEnumerable<TaskModel>> GetAllTasks()
    {
        return Ok(tasks);
    }

    [HttpGet("completed")]
    public ActionResult<IEnumerable<TaskModel>> GetAllCompletedTasks()
    {
        List<TaskModel> completedTasks = new List<TaskModel>();

        foreach (var task in tasks)
        {
            if (task.IsCompleted)
            {
                completedTasks.Add(task);
            }
        }

        return Ok(completedTasks);
    }

    [HttpGet("{id}")]
    public ActionResult<TaskModel> GetTaskById(int id)
    {
        var task = tasks.FirstOrDefault(t => t.Id == id);

        return Ok(task);
    }

    [HttpPut("{id}/change")]
    public ActionResult<IEnumerable<TaskModel>> EditTask(int id, [FromBody] TaskModel updatedTask)
    {
        var taskToUpdate = tasks.FirstOrDefault(t => t.Id == id);

        foreach (var task in tasks)
        {
            if (task.Id == id)
            {
                taskToUpdate = task;
                taskToUpdate.Description = updatedTask.Description;
                taskToUpdate.DueDate = updatedTask.DueDate;
                break;
            }
        }


        return Ok(taskToUpdate);
    }

    [HttpPatch("{id}/nowcompleted")]
    public ActionResult<IEnumerable<TaskModel>> MarkTaskAsCompleted(int id)
    {
        var task = tasks.FirstOrDefault(t => t.Id == id);
        task.IsCompleted = true;
        task.CompletionDate = DateTime.Now;
        Global.SaveTasksToFile();
        return Ok(task);
    }

    private void InitializeTasksFromJson()
    {
        var filePath = "Tasks.json";
        if (System.IO.File.Exists(filePath))
        {
            var json = System.IO.File.ReadAllText(filePath);
            tasks = JsonSerializer.Deserialize<List<TaskModel>>(json);

        }
    }
}