using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using TaskFinal;

namespace TaskFinal.Pages
{
	public class EditModel : PageModel
	{
		[BindProperty]
		public TaskModel EditTask { get; set; }

		public void OnGet(int id)
		{
			
			EditTask = Global.GetTaskById(id);

		}

		public IActionResult OnPost(int id)
		{
            
            var task = Global.GetTaskById(id);

			task.Id = id;
            task.Description = EditTask.Description;
            task.DueDate = EditTask.DueDate;
            task.IsCompleted = EditTask.IsCompleted;
            task.CompletionDate = EditTask.CompletionDate;

            Global.SaveTasksToFile();
            return RedirectToPage("Index");
        }
	}
}