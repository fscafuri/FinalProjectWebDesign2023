using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TaskFinal.Pages
{
	public class CompletedModel : PageModel
	{
		[BindProperty]
		public int TaskId { get; set; }

		public void OnGet(int id)
		{
	
			TaskId = id;

		}

		public IActionResult OnPost(int id)
		{
            var task = Global.GetTaskById(id);

			if (task != null) {
				task.IsCompleted = true;
				task.CompletionDate = DateTime.Now;
			}
            Global.SaveTasksToFile();
            return RedirectToPage("Index");

        }
	}
}